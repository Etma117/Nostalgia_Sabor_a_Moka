from django.contrib import admin
from . models import Producto, CategoriaMenu

# Register your models here.

admin.site.register(Producto)
admin.site.register(CategoriaMenu)