from django.contrib import admin
from .models import Carrito, Mesa

# Register your models here.

admin.site.register(Carrito)
admin.site.register(Mesa)